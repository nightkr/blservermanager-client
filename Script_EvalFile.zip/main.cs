function CleanEvalFile() {
	%fo = new FileObject();
	%fo.openForWrite("config/evalfile.cs");
	%fo.close();
	%fo.delete();
}

function EvalFile() {
	setModPaths(getModPaths());
	cancel($EvalFileSchedule);

	%fo = new FileObject();
	%fo.openForRead("config/evalfile.cs");
	while(!%fo.isEOF())
		%file = %file @ %fo.readLine() SPC "";
	eval(%file);
	%fo.close();
	%fo.delete();
	CleanEvalFile();

	$EvalFileSchedule = schedule(250, 0, EvalFile);
}

CleanEvalFile();
EvalFile();